// Customer.java
// Represents a customer of the electricity billing system

public class Customer {
    private int id;                // Unique customer ID
    private String name;           // Customer name
    private String address;        // Customer address
    private String meterNumber;    // Meter number assigned to the customer

    // ✅ Constructor to initialize all fields
    public Customer(int id, String name, String address, String meterNumber) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.meterNumber = meterNumber;
    }

    // ✅ Getter for customer ID
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    // ✅ Getter for meter number
    public String getMeterNumber() {
        return meterNumber;
    }
}
