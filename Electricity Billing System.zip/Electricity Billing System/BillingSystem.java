// Importing required classes
import java.util.*;

// Main class that contains the command-line interface (CLI) and logic for the Electricity Billing System
public class BillingSystem {

    // Scanner for reading user input
    private static Scanner scanner = new Scanner(System.in);

    // Stores customers using their ID as the key
    private static Map<Integer, Customer> customers = new HashMap<>();

    // Stores bills using their ID as the key
    private static Map<Integer, Bill> bills = new HashMap<>();

    // Counter to assign unique IDs to new customers and bills
    private static int customerIdCounter = 1;
    private static int billIdCounter = 1;

    // Fixed charges and rate per unit used for calculating bill amount
    private static final double FIXED_CHARGE = 50.0;
    private static final double RATE_PER_UNIT = 5.5;

    // Entry point of the application
    public static void main(String[] args) {
        // Infinite loop to show the menu until the user chooses to exit
        while (true) {
            // Display menu
            System.out.println("\n--- Electricity Billing System ---");
            System.out.println("1. Add Customer");
            System.out.println("2. Generate Bill");
            System.out.println("3. View Bill");
            System.out.println("4. Pay Bill");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            // Read user's choice
            int choice = Integer.parseInt(scanner.nextLine());

            // Perform action based on the selected option
            switch (choice) {
                case 1 -> addCustomer();     // Add new customer
                case 2 -> generateBill();    // Generate a new bill for a customer
                case 3 -> viewBill();        // View bill details
                case 4 -> payBill();         // Pay a pending bill
                case 5 -> {
                    System.out.println("Exiting... Goodbye!");
                    return; // Exit the program
                }
                default -> System.out.println("Invalid choice! Try again."); // Invalid input
            }
        }
    }

    // Method to add a new customer to the system
    private static void addCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        System.out.print("Enter meter number: ");
        String meterNumber = scanner.nextLine();

        // Create a new Customer object and store it in the map
        Customer customer = new Customer(customerIdCounter, name, address,meterNumber);
        customers.put(customerIdCounter, customer);

        System.out.println("Customer added with ID: " + customerIdCounter);
        customerIdCounter++; // Increment for next customer
    }

    // Method to generate an electricity bill for a customer
    private static void generateBill() {
        System.out.print("Enter Customer ID: ");
        int cId = Integer.parseInt(scanner.nextLine());

        // Check if customer exists
        if (!customers.containsKey(cId)) {
            System.out.println("Customer not found!");
            return;
        }

        // Ask how many units were consumed
        System.out.print("Enter units consumed: ");
        int units = Integer.parseInt(scanner.nextLine());

        // Calculate the amount using fixed charge + (unit rate * units)
        double amount = FIXED_CHARGE + (units * RATE_PER_UNIT);

        // Create new Bill object and store it
        Bill bill = new Bill(billIdCounter, cId, units, amount);
        bills.put(billIdCounter, bill);

        System.out.println("Bill generated with Bill ID: " + billIdCounter);
        System.out.println("Amount to pay: ₹" + amount);

        billIdCounter++; // Increment for next bill
    }

    // Method to view details of a specific bill
    private static void viewBill() {
        System.out.print("Enter Bill ID: ");
        int bId = Integer.parseInt(scanner.nextLine());

        // Retrieve bill
        Bill bill = bills.get(bId);

        if (bill == null) {
            System.out.println("Bill not found!");
            return;
        }

        // Get the associated customer
        Customer customer = customers.get(bill.getCustomerId());

        // Print bill and customer details
        System.out.println("\n--- Bill Details ---");
        System.out.println("Bill ID: " + bill.getBillId());
        System.out.println("Customer: " + customer.getName());
        System.out.println("Units Consumed: " + bill.getUnitsConsumed());
        System.out.println("Amount: ₹" + bill.getAmount());
        System.out.println("Paid Status: " + (bill.isPaid() ? "Paid" : "Pending"));
    }

    // Method to mark a bill as paid
    private static void payBill() {
        System.out.print("Enter Bill ID to pay: ");
        int bId = Integer.parseInt(scanner.nextLine());

        // Retrieve bill
        Bill bill = bills.get(bId);

        if (bill == null) {
            System.out.println("Bill not found!");
            return;
        }

        // Check if already paid
        if (bill.isPaid()) {
            System.out.println("Bill is already paid.");
            return;
        }

        // Mark bill as paid
        bill.isPaid();
        System.out.println("Bill paid successfully!");
    }
}
