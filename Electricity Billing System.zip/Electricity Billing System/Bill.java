public class Bill {
    private int billId;
    private int customerId;
    private double unitsConsumed;
    private double amount;
    private boolean isPaid;

    public Bill(int billId, int customerId, double unitsConsumed, double amount) {
        this.billId = billId;
        this.customerId = customerId;
        this.unitsConsumed = unitsConsumed;
        this.amount = amount;
        this.isPaid = false;
    }

    // ✅ Add these getters
    public int getBillId() {
        return billId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public double getUnitsConsumed() {
        return unitsConsumed;
    }

    public double getAmount() {
        return amount;
    }

    public boolean isPaid() {
        return isPaid;
    }

    // Optional setter for payment status
    public void setPaid(boolean paid) {
        this.isPaid = paid;
    }

   public void pay() {
    this.isPaid = true;  // Marks the bill as paid
}

}
