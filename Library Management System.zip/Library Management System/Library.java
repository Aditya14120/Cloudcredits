import java.util.ArrayList;

/**
 * The Library class serves as the central data storage for books and users.
 * It maintains two lists:
 * 1. A list for all the books in the library.
 * 2. A list for all the registered users in the library.
 */
public class Library {
    private ArrayList<Book> bookList; // List to store all the books in the library
    private ArrayList<User> userList; // List to store all the registered users of the library

    /**
     * Constructor to initialize the Library object with empty book and user lists.
     */
    public Library() {
        bookList = new ArrayList<>(); // Creates an empty list for books
        userList = new ArrayList<>(); // Creates an empty list for users
    }

    /**
     * Getter method to retrieve the list of all books in the library.
     *
     * @return The list of books (bookList).
     */
    public ArrayList<Book> getBookList() {
        return bookList; // Return the list of all books
    }

    /**
     * Getter method to retrieve the list of all users in the library.
     *
     * @return The list of users (userList).
     */
    public ArrayList<User> getUserList() {
        return userList; // Return the list of all users
    }

    /**
     * Adds a book to the library's book list.
     *
     * @param book The Book object to be added to the library.
     */
    public void addBook(Book book) {
        bookList.add(book); // Add the book to the book list
    }

    /**
     * Adds a user to the library's user list.
     *
     * @param user The User object to be added to the library.
     */
    public void addUser(User user) {
        userList.add(user); // Add the user to the user list
    }

    /**
     * Removes a book from the library's book list based on the unique book ID.
     *
     * @param book The Book object to be removed from the library.
     */
    public void removeBook(Book book) {
        // Remove the book from the list using its unique book ID
        bookList.removeIf(b -> b.getBookId() == book.getBookId());
    }

    /**
     * Finds and returns a book from the library's book list based on the book ID.
     * If the book is not found, it returns null.
     *
     * @param bookId The unique ID of the book to search for.
     * @return The Book object if found, or null if the book is not found.
     */
    public Book findBookById(int bookId) {
        // Loop through the book list to find a book by its ID
        for (Book book : bookList) {
            if (book.getBookId() == bookId) {
                return book; // Return the book if it matches the given ID
            }
        }
        return null; // Return null if the book with the specified ID is not found
    }

    /**
     * Finds and returns a user from the library's user list based on the user ID.
     * If the user is not found, it returns null.
     *
     * @param userId The unique ID of the user to search for.
     * @return The User object if found, or null if the user is not found.
     */
    public User findUserById(int userId) {
        // Loop through the user list to find a user by their ID
        for (User user : userList) {
            if (user.getUserId() == userId) {
                return user; // Return the user if their ID matches
            }
        }
        return null; // Return null if the user with the specified ID is not found
    }

    public Book findUserById(String valueOf) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findUserById'");
    }
}
