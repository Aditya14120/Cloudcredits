// The Book class represents a book in the library system
public class Book {
    private int bookid;    // Unique identifier for each book
    private String author; // Author of the book
    private String title;  // Title of the book
    private boolean isAvailable; // Indicates whether the book is available or borrowed

    /**
     * Constructor to initialize a new book object with the provided ID, title, and author.
     * By default, when a book is created, it is available (i.e., not borrowed).
     *
     * @param id     The unique ID assigned to the book
     * @param title  The title of the book
     * @param author The author of the book
     */
    public Book(int id, String title, String author) {
        this.bookid = id;    // Set the book's unique ID
        this.author = author; // Set the book's author
        this.title = title;  // Set the book's title
        this.isAvailable = true; // Book is available by default
    }

    /**
     * Getter method to retrieve the unique ID of the book.
     *
     * @return The unique book ID (bookid)
     */
    public int getBookId() {
        return bookid; // Return the unique ID of the book
    }

    /**
     * Getter method to retrieve the author of the book.
     *
     * @return The author of the book
     */
    public String getAuthor() {
        return author; // Return the author's name
    }

    /**
     * Getter method to retrieve the title of the book.
     *
     * @return The title of the book
     */
    public String getTitle() {
        return title; // Return the title of the book
    }

    /**
     * Getter method to check if the book is available or borrowed.
     *
     * @return true if the book is available, false if it is borrowed
     */
    public boolean isAvailable() {
        return isAvailable; // Return the availability status of the book
    }

    /**
     * Setter method to update the availability status of the book.
     * This is used when a book is borrowed or returned.
     *
     * @param available The new availability status of the book
     */
    public void setAvailable(boolean available) {
        this.isAvailable = available; // Update the availability status
    }

    /**
     * Override of the toString() method to provide a human-readable representation of the book.
     * This is used when printing the book object.
     *
     * @return A string representation of the book in the format: [ID] "Title" by Author - Available/Borrowed
     */
    @Override
    public String toString() {
        return "[" + bookid + "] \"" + title + "\" by " + author +
               " - " + (isAvailable ? "Available" : "Borrowed"); // Return a formatted string with book details
    }
}
