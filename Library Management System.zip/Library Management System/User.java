//Import all classes to work with the list
import java.util.ArrayList;
import java.util.List;

// The User class represents a library member who can borrow and return books
//Each user can borrow and return books
public class User {

    // Unique ID assigned to the user such as roll number 
    private int userId;

    // Name of the user
    private String name;

    // List to keep track of borrowed books
    private List<Book> borrowedBooks;

    // Constructor to create a new user with given ID and name
    // Also initialise the borrowed boooks as empty
    public User(int userId, String name) {
        this.userId = userId;               // Set the user's ID
        this.name = name;                   // Set the user's name
        this.borrowedBooks = new ArrayList<>(); // Initialize empty book list
    }

    // Getter method to return the user's ID
    public int getUserId() {
        return userId;
    }

    // Getter method to return the user's name
    public String getName() {
        return name;
    }

    // Method to return the list of borrowed books
    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    // Method to borrow a book
    //Book must be avaliable otherwise the user is notified
    public void borrowBook(Book book) {
        if (book.isAvailable()) {
            borrowedBooks.add(book);      // Add book to user's borrowed list
            book.setAvailable(false);     // Mark the book as borrowed
            System.out.println(name + " borrowed \"" + book.getTitle() + "\"");
        } else {//Book is already borrowed by someone else
            System.out.println("Sorry, the book \"" + book.getTitle() + "\" is not available.");
        }
    }
  

    // Method that allows user to return previously borrowed books
    public void returnBook(Book book) {
        if (borrowedBooks.contains(book)) {
            borrowedBooks.remove(book);   // Remove from user's list
            book.setAvailable(true);      // Mark book as available again
            System.out.println(name + " returned \"" + book.getTitle() + "\"");
        } else {//Book is not found in borrowed list
            System.out.println("You did not borrow this book.");
        }
    }

    // Method to display all books the user has borrowed already
    public void showBorrowedBooks() {
        if (borrowedBooks.isEmpty()) {//Check id the user has borrowed any books
            System.out.println(name + " has not borrowed any books.");
        } else {
            System.out.println(name + " has borrowed:");
            for (Book book : borrowedBooks) {//loops through each book
                System.out.println("  - " + book);//Print book details(toString is used)
            }
        }
    }
}
