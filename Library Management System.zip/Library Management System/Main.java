import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        // Sample books and users
        library.addBook(new Book(1, "The Alchemist", "Paulo Coelho"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addUser(new User(101, "Alice"));
        library.addUser(new User(102, "Bob"));

        int choice;

        do {
            System.out.println("\n--- Library Management Menu ---");
            System.out.println("1. View all books");
            System.out.println("2. View all users");
            System.out.println("3. Borrow book");
            System.out.println("4. Return book");
            System.out.println("5. Show borrowed books");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nAvailable Books:");
                    for (Book book : library.getBookList()) {
                        System.out.println(book);
                    }
                    break;

                case 2:
                    System.out.println("\nRegistered Users:");
                    for (User user : library.getUserList()) {
                        System.out.println("ID: " + user.getUserId() + ", Name: " + user.getName());
                    }
                    break;

                case 3:
                    System.out.print("Enter User ID: ");
                    int borrowUserId = scanner.nextInt();
                    System.out.print("Enter Book ID: ");
                    int borrowBookId = scanner.nextInt();

                    User borrower = library.findUserById(borrowUserId);
                    Book bookToBorrow = library.findBookById(borrowBookId);

                    if (borrower != null && bookToBorrow != null) {
                        borrower.borrowBook(bookToBorrow);
                    } else {
                        System.out.println("Invalid User ID or Book ID.");
                    }
                    break;

                case 4:
                    System.out.print("Enter User ID: ");
                    int returnUserId = scanner.nextInt();
                    System.out.print("Enter Book ID: ");
                    int returnBookId = scanner.nextInt();

                    User returner = library.findUserById(returnUserId);
                    Book bookToReturn = library.findBookById(returnBookId);

                    if (returner != null && bookToReturn != null) {
                        returner.returnBook(bookToReturn);
                    } else {
                        System.out.println("Invalid User ID or Book ID.");
                    }
                    break;

                case 5:
                    System.out.print("Enter User ID: ");
                    int viewUserId = scanner.nextInt();
                    User viewer = library.findUserById(viewUserId);

                    if (viewer != null) {
                        viewer.showBorrowedBooks();
                    } else {
                        System.out.println("User not found.");
                    }
                    break;

                case 6:
                    System.out.println("Exiting Library System. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 6);

        scanner.close();
    }
}
