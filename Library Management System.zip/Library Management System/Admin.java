import java.util.ArrayList;

/**
 * Admin class handles administrative tasks in the library management system.
 * Admin can view all books, remove any book, and view registered users.
 */
public class Admin {
    private String adminId;  // Unique Identifier for Admin
    private String name;     // To store the name of the admin
    private String password; // To store password for each admin

    /**
     * Constructor to initialize Admin object with ID, name, and password.
     * @param adminId Unique ID for admin
     * @param name Name of the admin
     * @param password Password for login authentication
     */
    public Admin(String adminId, String name, String password) {
        this.adminId = adminId;
        this.name = name;
        this.password = password;
    }

    /**
     * Getter for admin Id.
     * @return adminId
     */
    public String getAdminId() {
        return adminId;
    }

    /**
     * Getter for name.
     * @return Admin's name
     */
    public String getName() {
        return name;
    }

    /**
     * Adds book to the library's book list.
     * @param book The book object to be added
     * @param bookList The list that holds all the books
     */
    public void addBook(Book book, ArrayList<Book> bookList) {
        bookList.add(book); // Adds the book to the list
        System.out.println("Book added successfully: " + book.getTitle());
    }

    /**
     * Removes the book from the library using its unique ID.
     * @param bookId Unique ID of the book
     * @param bookList The ArrayList containing all books
     */
    public void removeBook(int bookId, ArrayList<Book> bookList) { // Changed bookId to int
        boolean removed = false;
        for (Book book : bookList) {
            if (book.getBookId() == bookId) { // Changed getBookId() to getId()
                bookList.remove(book); // Removes book from the list
                System.out.println("Book removed successfully: " + book.getTitle());
                removed = true;
                break;
            }
        }
        // Message to print if the book is not found
        if (!removed) {
            System.out.println("Book not found with ID: " + bookId);
        }
    }

    /**
     * Displays all the books in the library.
     * @param bookList The ArrayList containing all books
     */
    public void viewAllBooks(ArrayList<Book> bookList) {
        if (bookList.isEmpty()) {
            System.out.println("No books in the library.");
            return;
        }

        System.out.println("Books in the Library:");
        for (Book book : bookList) {
            System.out.println(book); // Assumes book class has a toString method
        }
    }

    /**
     * Displays all registered users of the library.
     * @param userList The ArrayList containing all users
     */
    public void viewAllUsers(ArrayList<User> userList) {
        if (userList.isEmpty()) {
            System.out.println("No registered users.");
            return;
        }

        System.out.println("Registered Users:");
        for (User user : userList) {
            System.out.println(user); // Assumes user class has a toString() method
        }
    }

    /**
     * Authenticates the admin based on the entered password.
     * @param enteredPassword Password entered by the user
     * @return true if password matches, false otherwise
     */
    public boolean authenticate(String enteredPassword) {
        return this.password.equals(enteredPassword);
    }
}
