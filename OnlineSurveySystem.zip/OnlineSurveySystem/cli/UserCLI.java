package cli;

import managers.SurveyManager;
import models.Survey;
import models.Question;
import java.util.Scanner;

// CLI for user actions: take surveys
public class UserCLI {
    public static void start(Scanner scanner) {
        System.out.println("\n--- User: Take a Survey ---");

        if (SurveyManager.getSurveys().isEmpty()) {
            System.out.println("No surveys available.");
            return;
        }

        for (Survey s : SurveyManager.getSurveys()) {
            System.out.println(s);
        }

        System.out.print("Enter Survey ID to take: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Survey survey = SurveyManager.getSurveyById(id);
        if (survey == null) {
            System.out.println("Survey not found.");
            return;
        }

        System.out.println("Answer the following questions:");
        for (Question q : survey.getQuestions()) {
            System.out.println(q.getQuestionText());
            System.out.print("Your answer: ");
            scanner.nextLine(); // For now, we're not storing responses
        }

        System.out.println("Thank you for completing the survey.");
    }
}
