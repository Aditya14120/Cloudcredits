package cli;

import managers.SurveyManager;
import models.Question;
import models.Survey;
import java.util.Scanner;

// CLI for admin actions: create and view surveys
public class AdminCLI {
    public static void start(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Create Survey");
            System.out.println("2. List Surveys");
            System.out.println("3. Back");
            System.out.print("Choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createSurvey(scanner);
                    break;
                case 2:
                    listSurveys();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void createSurvey(Scanner scanner) {
        System.out.print("Enter Survey ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Survey Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Description: ");
        String desc = scanner.nextLine();

        Survey survey = new Survey(id, title, desc);

        System.out.print("How many questions? ");
        int count = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < count; i++) {
            System.out.print("Enter question " + (i + 1) + ": ");
            String qText = scanner.nextLine();
            survey.addQuestion(new Question(qText));
        }

        SurveyManager.addSurvey(survey);
        System.out.println("Survey created successfully.");
    }

    private static void listSurveys() {
        for (Survey s : SurveyManager.getSurveys()) {
            System.out.println(s);
        }
    }
}
