package models;

import java.util.ArrayList;
import java.util.List;

// Represents a survey with title, description, and a list of questions
public class Survey {
    private int id;
    private String title;
    private String description;
    private List<Question> questions;

    public Survey(int id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.questions = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void addQuestion(Question question) {
        if (question != null) {
            questions.add(question);
        }
    }

    public void removeQuestion(int index) {
        if (index >= 0 && index < questions.size()) {
            questions.remove(index);
        }
    }

    public int getQuestionCount() {
        return questions.size();
    }

    @Override
    public String toString() {
        return "Survey ID: " + id + "\nTitle: " + title + "\nDescription: " + description + "\nQuestions: " + questions.size();
    }
}
