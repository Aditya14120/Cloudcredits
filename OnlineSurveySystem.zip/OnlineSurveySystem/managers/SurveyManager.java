package managers;

import models.Survey;
import java.util.ArrayList;
import java.util.List;

// Handles survey management logic (add, get, list surveys)
public class SurveyManager {
    private static List<Survey> surveys = new ArrayList<>();

    public static void addSurvey(Survey survey) {
        surveys.add(survey);
    }

    public static List<Survey> getSurveys() {
        return surveys;
    }

    public static Survey getSurveyById(int id) {
        for (Survey s : surveys) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }
}
