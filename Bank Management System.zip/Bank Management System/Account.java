//Account.java 
//The class containing a single account with basic operation
public class Account {
    //=====Private attributes of a program=======
    //This is use to store the account number of the user 
    private String accountNumber;
    //This is use to store the name of the user
    private String name;
    //This is use to store the pin by the user
    private String pin;
    //This is use to asstore the balance of the user
    private double balance;
    //=====Constructer======
    //To Initialize details for the account of new User
    public Account(String accountNumber, String name, String pin, double balance) {
        this.accountNumber = accountNumber;
        this.name = name;
        this.pin = pin;
        this.balance = balance;
    }

    //=======Getter methods======
    //Use to access private data from outside the class 
    public String getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }

    public String getPin() {
        return pin;
    }

    public double getBalance() {
        return balance;
    }

    //======Setter method=======
    //Use to update the pin
    public void setPin(String newPin) {
        this.pin = newPin;
    }

    //======Deposit method=====
    //Add money to the current balance
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
        else{
            System.out.println("Enter a valid amount");
        }
    }//If the amount is invalid Counter message is printed

    //=====Withdraw method=====
    //Deducts money from present balance if enough amount is availiable 
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;//Withdrawal Sucess
        }
        return false;//Withdrawal fail due to insufficient balance
    }
}
