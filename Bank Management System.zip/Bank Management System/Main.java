import java.util.Scanner; // Importing Scanner class for user input

// Main class to start the Bank Management System
public class Main {

    public static void main(String[] args) {

        // Create a Scanner object to read input from the console
        Scanner sc = new Scanner(System.in);

        // Create an instance of the Bank class to manage accounts
        Bank bank = new Bank();

        // Main menu loop
        while (true) {
            System.out.println("\n===== Welcome to Simple Bank System =====");
            System.out.println("1. Admin Login");
            System.out.println("2. User Login");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();  // Consume newline character left by nextInt()

            // Handle user choice
            switch (choice) {
                case 1:
                    // Open Admin menu
                    adminMenu(sc, bank);
                    break;
                case 2:
                    // Proceed to user login and menu
                    userLogin(sc, bank);
                    break;
                case 3:
                    // Exit the program
                    System.out.println(" Thank you for using our Bank System. Goodbye!");
                    sc.close(); // Close scanner
                    return; // End main method
                default:
                    System.out.println(" Invalid choice. Please try again.");
            }
        }
    }

    // === Admin Menu Function ===
    // Handles all admin-related options: create, view, delete accounts
    public static void adminMenu(Scanner sc, Bank bank) {
        while (true) {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("1. Create New Account");
            System.out.println("2. View All Accounts");
            System.out.println("3. Delete Account");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int adminChoice = sc.nextInt();
            sc.nextLine();  // Consume newline character

            switch (adminChoice) {
                case 1:
                    // Creating a new account
                    System.out.print("Enter account number: ");
                    String accNo = sc.nextLine();

                    System.out.print("Enter account holder name: ");
                    String name = sc.nextLine();

                    System.out.print("Set 4-digit PIN: ");
                    String pin = sc.nextLine();

                    System.out.print("Initial deposit amount: ");
                    double deposit = sc.nextDouble();

                    // Call Bank's method to create account
                    bank.createAccount(accNo, name, pin, deposit);
                    break;

                case 2:
                    // Display all existing accounts
                    bank.displayAllAccounts();
                    break;

                case 3:
                    // Deleting an account
                    System.out.print("Enter account number to delete: ");
                    String delAccNo = sc.nextLine();

                    boolean deleted = bank.deleteAccount(delAccNo);
                    if (!deleted) {
                        System.out.println(" Account not found.");
                    }
                    break;

                case 4:
                    // Go back to main menu
                    return;

                default:
                    System.out.println(" Invalid choice.");
            }
        }
    }

    // === User Login Function ===
    // Authenticates user and shows user menu if login is successful
    public static void userLogin(Scanner sc, Bank bank) {
        System.out.print("Enter your account number: ");
        String accNo = sc.nextLine();

        System.out.print("Enter your 4-digit PIN: ");
        String pin = sc.nextLine();

        // Authenticate user
        Account user = bank.authenticate(accNo, pin);

        if (user != null) {
            System.out.println(" Login successful. Welcome, " + user.getName() + "!");
            userMenu(sc, user); // Show user menu after login
        } else {
            System.out.println(" Invalid account number or PIN.");
        }
    }

    // === User Menu Function ===
    // Provides banking options to authenticated user
    public static void userMenu(Scanner sc, Account user) {
        while (true) {
            System.out.println("\n=== User Menu ===");
            System.out.println("1. View Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Change PIN");
            System.out.println("5. Logout");
            System.out.print("Enter your choice: ");
            int userChoice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (userChoice) {
                case 1:
                    // Show current balance
                    System.out.println("Current Balance: ₹" + user.getBalance());
                    break;

                case 2:
                    // Deposit money
                    System.out.print("Enter amount to deposit: ");
                    double depAmt = sc.nextDouble();
                    sc.nextLine();
                    user.deposit(depAmt);
                    System.out.println(" ₹" + depAmt + " deposited successfully.");
                    break;

                case 3:
                    // Withdraw money
                    System.out.print("Enter amount to withdraw: ");
                    double wdAmt = sc.nextDouble();
                    sc.nextLine();
                    if (user.withdraw(wdAmt)) {
                        System.out.println(" ₹" + wdAmt + " withdrawn successfully.");
                    } else {
                        System.out.println(" Insufficient balance or invalid amount.");
                    }
                    break;

                case 4:
                    // Change PIN
                    System.out.print("Enter new 4-digit PIN: ");
                    String newPin = sc.nextLine();
                    user.setPin(newPin);
                    System.out.println(" PIN changed successfully.");
                    break;

                case 5:
                    // Logout and return to main menu
                    System.out.println(" Logged out successfully.");
                    return;

                default:
                    System.out.println(" Invalid choice. Please try again.");
            }
        }
    }
}
