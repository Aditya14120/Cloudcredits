import java.util.ArrayList;
import java.util.List;

// Bank.java
// This class manages all accounts and provides admin-level and user-level operations
//It manages all bank accounts and provide admin/user-level operations. 

public class Bank {

    //====Data Member====
    //A dynamic list to store all account objects

    private List<Account> accounts;

    //====Constructor====
    //Initialise the account list when bank Object is created.
    public Bank() {
        accounts = new ArrayList<>();
    }

    // === Method to create a new account ===
    //This method creates new account and adds it to the account list
    public void createAccount(String accountNumber, String name, String pin, double initialDeposit) {
        Account newAccount = new Account(accountNumber, name, pin, initialDeposit);
        accounts.add(newAccount);
        System.out.println(" Account created successfully for " + name);
    }

    // === Method to delete an account using account number ===
    public boolean deleteAccount(String accountNumber) {
        Account acc = getAccount(accountNumber);//Search for the account
        if (acc != null) {
            accounts.remove(acc);//Removes the account from the list
            System.out.println(" Account " + accountNumber + " deleted successfully.");
            return true;
        }//If account is not found return false
        return false;
    }

    // === Method to search for an account by account number ===
    public Account getAccount(String accountNumber) {
        for (Account acc : accounts) {
            if (acc.getAccountNumber().equals(accountNumber)) {
                return acc;
            }
        }
        return null; // Not found
    }

    // === Method to authenticate user using account number and pin ===
    public Account authenticate(String accountNumber, String pin) {
        Account acc = getAccount(accountNumber);
        if (acc != null && acc.getPin().equals(pin)) {
            return acc; // Authentication successful
        }
        return null; // Failed
    }

    // === Method to display all accounts ===
    //Displays accounts present in the bank system
    public void displayAllAccounts() {
        System.out.println(" All Bank Accounts:");
        if (accounts.isEmpty()) {
            System.out.println(" No accounts found.");
        } else {
            for (Account acc : accounts) {
                //Print basic details of all account
                System.out.println("Account Number: " + acc.getAccountNumber()
                                 + ", Name: " + acc.getName()
                                 + ", Balance: ₹" + acc.getBalance());
            }
        }
    }
}
